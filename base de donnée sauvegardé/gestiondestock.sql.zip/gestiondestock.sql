-- phpMyAdmin SQL Dump
-- version 3.3.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: May 23, 2017 at 08:44 AM
-- Server version: 5.1.66
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gestiondestock`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `reference` varchar(20) NOT NULL,
  `libelleproduit` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `id_categorie` int(11) NOT NULL,
  `id_unite` int(11) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `codebarrefournisseur` varchar(100) NOT NULL,
  `codebarreinterne` varchar(100) NOT NULL,
  `stockalerte` int(11) NOT NULL,
  `saisipar` varchar(100) NOT NULL,
  `saisile` date NOT NULL,
  PRIMARY KEY (`reference`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`reference`, `libelleproduit`, `description`, `id_categorie`, `id_unite`, `photo`, `codebarrefournisseur`, `codebarreinterne`, `stockalerte`, `saisipar`, `saisile`) VALUES
('CAMP0001', 'Gourde', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('CAMP0002', 'Gamelle 03 éléments PH', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('CAMP0003', 'Bêche', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('CAMP0004', 'Bouthéon', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0005', 'Gamelle locale', '3 éléments', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0006', 'Marmite de 100l', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0007', 'Marmite de 60l', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0008', 'Marmite de 50l', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0009', 'Marmite de 45l', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0010', 'Tente de 2 places', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0011', 'Tente de 24 places', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0012', 'Tente de 4 places', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0013', 'Louche GM', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0001', 'Couverture VA PH', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('CCG0002', 'Armature lits picots', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0003', 'Couverture SOMACOU', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0004', 'Matelas de 10 cm', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0005', 'Moustiquaire', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0006', 'Toile lits picots', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0007', 'Traversin', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0008', 'Matelas  8cm', 'MADAFOAM', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0009', 'Lits picots', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0010', 'Matelas 14 EM', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0011', 'Matelas 14 TM', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0001', 'Drapeau N°05', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0002', 'Drapeau N°03', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0003', 'Drapeau 6m', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0004', 'Drapeau 22m', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0005', 'Drapeau N°01', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0006', 'Pavoisement', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0001', 'Toile juté', '', 4, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0002', 'Bouton VA 14', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0003', 'Bouton VA 16', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0004', 'Bouton vert savane 18', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0005', 'Bouton vert lampda', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0006', 'Bouton blanc 18', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0007', 'Bouton blanc 14', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0008', 'Bouton bleu 14', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0009', 'Bouton blanc 8', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0010', 'Bouton noir 12', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0011', 'Bouton noir 14', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0012', 'Bouton pression métalique 12', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0013', 'Bouton bleu 16', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0014', 'Bouton violet', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0015', 'Bouton vert olive 14', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0016', 'Bouton vert foncé 16', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0001', 'Rangers resistance oil', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0002', 'Chaussette verte', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0003', 'Chaussette noire PH', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0004', 'Chaussette de sport blanche PH', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0005', 'Débardeur VA', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0006', 'Sac d''hydratation', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0007', 'Castan camouflée', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0008', 'Survêtement bleu', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0009', 'Ceinturon TAP VA PH', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0010', 'Chaussure basse noire PH', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0011', 'Rangers BGB', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0012', 'Tenue de combat MARCK', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0013', 'Tenue de combat desert', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0014', 'Bérét amarante rouge PR', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0015', 'Béret vert PR', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0016', 'Ceinture TAP VA PR', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0017', 'Béret rouge amarante locale', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0018', 'Béret vert locale', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0019', 'Chemise vert olive ', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0020', 'Tenue courte bleu', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0021', 'Epaulette rouge', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0022', 'Ceinture en cuir noir', 'petit', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0023', 'Ceinturon en cuir', 'TAP', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0024', 'Chaussure basse  noir locale', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0025', 'Sandalette', 'J.R', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0026', 'Chandail VA', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0027', 'Ceinture blanche', 'petit', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0028', 'Ceinture de pantalon VA', 'petit', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0029', 'Chaussette noir locale', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0030', 'Chemise blanche', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0031', 'Chemise bleu ciel', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0032', 'Chemise bleu ciel locale', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0033', 'Cravate TM', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0034', 'Espadrille', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0035', 'Imperméable VA', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0036', 'Kiranyl', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0037', 'Lacet blanc', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0038', 'Pantalon viscose', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0039', 'Parka', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0040', 'Poncho camouflée', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0041', 'Mi-bas VA', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0042', 'Casque lourd', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0043', 'Sac au dos camouflée ', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0044', 'Slip pour homme', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0045', 'Gant blanc', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0046', 'Slip blanche GM', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0047', 'Tricot rayée', 'BANA', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0048', 'Lacet noir', '60 cm', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0049', 'Ceinture synthétique', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0050', 'Insigne de béret', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0051', 'Macaron', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('TIS0001', 'Tissu vert lampda', 'sous-officier', 5, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('TIS0002', 'Tissu vert savane', '', 5, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('TIS0003', 'Doublure noir', '', 5, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('TIS0004', 'Doublure bleu', '', 5, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('TIS0005', 'Triplure collante', '', 5, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03');

-- --------------------------------------------------------

--
-- Table structure for table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `id_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `categorie` varchar(50) NOT NULL,
  PRIMARY KEY (`id_categorie`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `categorie`
--

INSERT INTO `categorie` (`id_categorie`, `categorie`) VALUES
(1, 'HABILLEMENT'),
(2, 'COUCHAGE'),
(3, 'CAMPEMENT'),
(4, 'FOURNITURE DIVERS'),
(5, 'TISSU'),
(6, 'DRAPEAU');

-- --------------------------------------------------------

--
-- Table structure for table `compte`
--

CREATE TABLE IF NOT EXISTS `compte` (
  `id_compte` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `nomprenom` varchar(100) NOT NULL,
  `etsouservice` varchar(50) NOT NULL,
  `motdepasse` varchar(50) NOT NULL,
  PRIMARY KEY (`id_compte`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `compte`
--

INSERT INTO `compte` (`id_compte`, `login`, `nomprenom`, `etsouservice`, `motdepasse`) VALUES
(1, 'tantely', 'RASOARINIRINA Tantely Malala Annick', 'ECMAG APPRO', 'tantely'),
(2, 'fanasina', 'Tina', 'ROGER', 'mamolava');

-- --------------------------------------------------------

--
-- Table structure for table `detail_mouvement`
--

CREATE TABLE IF NOT EXISTS `detail_mouvement` (
  `id_detail_mouvement` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(20) NOT NULL,
  `libelleproduit` varchar(100) NOT NULL,
  `id_mouvement` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  `etat` varchar(50) NOT NULL,
  `observation` varchar(200) NOT NULL,
  PRIMARY KEY (`id_detail_mouvement`),
  KEY `WDIDX14929705165` (`reference`),
  KEY `WDIDX14929705176` (`id_mouvement`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `detail_mouvement`
--


-- --------------------------------------------------------

--
-- Table structure for table `etat`
--

CREATE TABLE IF NOT EXISTS `etat` (
  `etat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `etat`
--

INSERT INTO `etat` (`etat`) VALUES
('En attente de retour'),
('Manquant'),
('Reglé');

-- --------------------------------------------------------

--
-- Table structure for table `etatdestock`
--

CREATE TABLE IF NOT EXISTS `etatdestock` (
  `reference` varchar(20) NOT NULL,
  `quantite_initiale` int(11) NOT NULL,
  `quantite_entree` int(11) NOT NULL,
  `quantite_sortie` int(11) NOT NULL,
  `stockfinal` int(11) NOT NULL,
  `ecart` int(11) NOT NULL,
  `observation` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `etatdestock`
--

INSERT INTO `etatdestock` (`reference`, `quantite_initiale`, `quantite_entree`, `quantite_sortie`, `stockfinal`, `ecart`, `observation`) VALUES
('CAMP0001', 0, 0, 0, 0, 0, ''),
('CAMP0002', 0, 0, 0, 0, 0, ''),
('CAMP0003', 0, 0, 0, 0, 0, ''),
('CAMP0004', 0, 0, 0, 0, 0, ''),
('CAMP0005', 0, 0, 0, 0, 0, ''),
('CAMP0006', 0, 0, 0, 0, 0, ''),
('CAMP0007', 0, 0, 0, 0, 0, ''),
('CAMP0008', 0, 0, 0, 0, 0, ''),
('CAMP0009', 0, 0, 0, 0, 0, ''),
('CAMP0010', 0, 0, 0, 0, 0, ''),
('CAMP0011', 0, 0, 0, 0, 0, ''),
('CAMP0012', 0, 0, 0, 0, 0, ''),
('CAMP0013', 0, 0, 0, 0, 0, ''),
('CCG0001', 0, 0, 0, 0, 0, ''),
('CCG0002', 0, 0, 0, 0, 0, ''),
('CCG0003', 0, 0, 0, 0, 0, ''),
('CCG0004', 0, 0, 0, 0, 0, ''),
('CCG0005', 0, 0, 0, 0, 0, ''),
('CCG0006', 0, 0, 0, 0, 0, ''),
('CCG0007', 0, 0, 0, 0, 0, ''),
('CCG0008', 0, 0, 0, 0, 0, ''),
('CCG0009', 0, 0, 0, 0, 0, ''),
('CCG0010', 0, 0, 0, 0, 0, ''),
('CCG0011', 0, 0, 0, 0, 0, ''),
('DRA0001', 0, 0, 0, 0, 0, ''),
('DRA0002', 0, 0, 0, 0, 0, ''),
('DRA0003', 0, 0, 0, 0, 0, ''),
('DRA0004', 0, 0, 0, 0, 0, ''),
('DRA0005', 0, 0, 0, 0, 0, ''),
('DRA0006', 0, 0, 0, 0, 0, ''),
('FOU0001', 0, 0, 0, 0, 0, ''),
('FOU0002', 0, 0, 0, 0, 0, ''),
('FOU0003', 0, 0, 0, 0, 0, ''),
('FOU0004', 0, 0, 0, 0, 0, ''),
('FOU0005', 0, 0, 0, 0, 0, ''),
('FOU0006', 0, 0, 0, 0, 0, ''),
('FOU0007', 0, 0, 0, 0, 0, ''),
('FOU0008', 0, 0, 0, 0, 0, ''),
('FOU0009', 0, 0, 0, 0, 0, ''),
('FOU0010', 0, 0, 0, 0, 0, ''),
('FOU0011', 0, 0, 0, 0, 0, ''),
('FOU0012', 0, 0, 0, 0, 0, ''),
('FOU0013', 0, 0, 0, 0, 0, ''),
('FOU0014', 0, 0, 0, 0, 0, ''),
('FOU0015', 0, 0, 0, 0, 0, ''),
('FOU0016', 0, 0, 0, 0, 0, ''),
('HAB0001', 0, 0, 0, 0, 0, ''),
('HAB0002', 0, 0, 0, 0, 0, ''),
('HAB0003', 0, 0, 0, 0, 0, ''),
('HAB0004', 0, 0, 0, 0, 0, ''),
('HAB0005', 0, 0, 0, 0, 0, ''),
('HAB0006', 0, 0, 0, 0, 0, ''),
('HAB0007', 0, 0, 0, 0, 0, ''),
('HAB0008', 0, 0, 0, 0, 0, ''),
('HAB0009', 0, 0, 0, 0, 0, ''),
('HAB0010', 0, 0, 0, 0, 0, ''),
('HAB0011', 0, 0, 0, 0, 0, ''),
('HAB0012', 0, 0, 0, 0, 0, ''),
('HAB0013', 0, 0, 0, 0, 0, ''),
('HAB0014', 0, 0, 0, 0, 0, ''),
('HAB0015', 0, 0, 0, 0, 0, ''),
('HAB0016', 0, 0, 0, 0, 0, ''),
('HAB0017', 0, 0, 0, 0, 0, ''),
('HAB0018', 0, 0, 0, 0, 0, ''),
('HAB0019', 0, 0, 0, 0, 0, ''),
('HAB0020', 0, 0, 0, 0, 0, ''),
('HAB0021', 0, 0, 0, 0, 0, ''),
('HAB0022', 0, 0, 0, 0, 0, ''),
('HAB0023', 0, 0, 0, 0, 0, ''),
('HAB0024', 0, 0, 0, 0, 0, ''),
('HAB0025', 0, 0, 0, 0, 0, ''),
('HAB0026', 0, 0, 0, 0, 0, ''),
('HAB0027', 0, 0, 0, 0, 0, ''),
('HAB0028', 0, 0, 0, 0, 0, ''),
('HAB0029', 0, 0, 0, 0, 0, ''),
('HAB0030', 0, 0, 0, 0, 0, ''),
('HAB0031', 0, 0, 0, 0, 0, ''),
('HAB0032', 0, 0, 0, 0, 0, ''),
('HAB0033', 0, 0, 0, 0, 0, ''),
('HAB0034', 0, 0, 0, 0, 0, ''),
('HAB0035', 0, 0, 0, 0, 0, ''),
('HAB0036', 0, 0, 0, 0, 0, ''),
('HAB0037', 0, 0, 0, 0, 0, ''),
('HAB0038', 0, 0, 0, 0, 0, ''),
('HAB0039', 0, 0, 0, 0, 0, ''),
('HAB0040', 0, 0, 0, 0, 0, ''),
('HAB0041', 0, 0, 0, 0, 0, ''),
('HAB0042', 0, 0, 0, 0, 0, ''),
('HAB0043', 0, 0, 0, 0, 0, ''),
('HAB0044', 0, 0, 0, 0, 0, ''),
('HAB0045', 0, 0, 0, 0, 0, ''),
('HAB0046', 0, 0, 0, 0, 0, ''),
('HAB0047', 0, 0, 0, 0, 0, ''),
('HAB0048', 0, 0, 0, 0, 0, ''),
('HAB0049', 0, 0, 0, 0, 0, ''),
('HAB0050', 0, 0, 0, 0, 0, ''),
('HAB0051', 0, 0, 0, 0, 0, ''),
('TIS0001', 0, 0, 0, 0, 0, ''),
('TIS0002', 0, 0, 0, 0, 0, ''),
('TIS0003', 0, 0, 0, 0, 0, ''),
('TIS0004', 0, 0, 0, 0, 0, ''),
('TIS0005', 0, 0, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `etsouservice`
--

CREATE TABLE IF NOT EXISTS `etsouservice` (
  `id_etsouservice` int(11) NOT NULL AUTO_INCREMENT,
  `etsouservice` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `libelle` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_etsouservice`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `etsouservice`
--

INSERT INTO `etsouservice` (`id_etsouservice`, `etsouservice`, `SE`, `libelle`) VALUES
(1, '1°RTS', 'CORPS', ''),
(2, 'CAPSAT', 'CORPS', ''),
(3, '1/RM1', 'CORPS', ''),
(4, '1/RM2', 'CORPS', ''),
(5, '1/RM3', 'CORPS', ''),
(6, '1/RM4', 'CORPS', ''),
(7, '1/RM5', 'CORPS', ''),
(8, '1/RM7', 'CORPS', ''),
(9, '1°RFI', 'CORPS', ''),
(10, '2°RG', 'CORPS', ''),
(11, '2/RM4', 'CORPS', ''),
(12, 'BATAC', 'CORPS', ''),
(13, 'BANI', 'CORPS', ''),
(14, 'BANA', 'CORPS', ''),
(15, '2/RM2', 'CORPS', ''),
(16, '2/RM5', 'CORPS', ''),
(17, '3/RM5', 'CORPS', ''),
(18, 'RAS', 'CORPS', ''),
(19, 'RAAA', 'CORPS', ''),
(20, 'RAL', 'CORPS', ''),
(21, '1°RG', 'CORPS', ''),
(22, '3°RG', 'CORPS', ''),
(23, '2°RFI', 'CORPS', ''),
(24, 'CPC', 'CORPS', ''),
(25, 'RECAMP', 'CORPS', ''),
(26, 'ACMIL', 'ECOLE', ''),
(27, 'SEMIPI', 'ECOLE', ''),
(28, 'ENSOA', 'ECOLE', ''),
(29, 'DMT', 'Direction', ''),
(30, 'COFIA', 'Région', ''),
(31, 'EMGAM/DLD', 'Etat major', ''),
(32, 'EMGAM/SERDIS', 'Etat Major', ''),
(33, 'GP', 'Garde présidentiel', ''),
(34, 'MUSAM', '', ''),
(35, 'EMIV', 'Etablissement DIA', ''),
(36, 'SMAD', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `fichedestock`
--

CREATE TABLE IF NOT EXISTS `fichedestock` (
  `reference` varchar(100) NOT NULL,
  `date` date DEFAULT NULL,
  `numerodelapj` varchar(50) NOT NULL,
  `provenanceoudestination` varchar(100) NOT NULL,
  `BLouBMS` varchar(50) NOT NULL,
  `dues` int(11) NOT NULL,
  `quantiteentree` int(11) NOT NULL,
  `quantitesortie` int(11) NOT NULL,
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fichedestock`
--


-- --------------------------------------------------------

--
-- Table structure for table `fournisseurs`
--

CREATE TABLE IF NOT EXISTS `fournisseurs` (
  `id_fournisseurs` int(11) NOT NULL AUTO_INCREMENT,
  `societe` varchar(200) NOT NULL,
  `civilite` varchar(20) NOT NULL,
  `nomprenom` varchar(200) NOT NULL,
  `adresse` varchar(200) NOT NULL,
  `codepostal` varchar(10) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `telephone` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `observation` varchar(100) NOT NULL,
  PRIMARY KEY (`id_fournisseurs`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `fournisseurs`
--

INSERT INTO `fournisseurs` (`id_fournisseurs`, `societe`, `civilite`, `nomprenom`, `adresse`, `codepostal`, `ville`, `telephone`, `mail`, `observation`) VALUES
(1, 'SARL', '1', 'RAKOTO MAKAKA', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `inventaire`
--

CREATE TABLE IF NOT EXISTS `inventaire` (
  `id_inventaire` int(11) NOT NULL,
  `reference` varchar(20) NOT NULL,
  `libelleproduit` varchar(100) NOT NULL,
  `qteinitiale` int(11) NOT NULL,
  `qteentree` int(11) NOT NULL,
  `qtesortie` int(11) NOT NULL,
  `stockreel` int(11) NOT NULL,
  `stockphysique` int(11) NOT NULL,
  `ecart` int(11) NOT NULL,
  `remarque` varchar(200) NOT NULL,
  KEY `WDIDX14930375530` (`id_inventaire`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventaire`
--


-- --------------------------------------------------------

--
-- Table structure for table `mouvement`
--

CREATE TABLE IF NOT EXISTS `mouvement` (
  `id_mouvement` int(11) NOT NULL AUTO_INCREMENT,
  `id_fournisseur` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `destination` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `numerodelapj` varchar(50) NOT NULL,
  `BLouBMS` varchar(50) NOT NULL,
  `id_mouvement_anterieur` int(11) NOT NULL,
  `regulariser` varchar(100) NOT NULL,
  `saisipar` varchar(100) NOT NULL,
  `saisile` date NOT NULL,
  PRIMARY KEY (`id_mouvement`),
  KEY `WDIDX14929705020` (`id_fournisseur`),
  KEY `WDIDX14929705031` (`type`),
  KEY `WDIDX14929705032` (`source`),
  KEY `WDIDX14929705033` (`destination`),
  KEY `WDIDX14929705034` (`id_mouvement_anterieur`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `mouvement`
--


-- --------------------------------------------------------

--
-- Table structure for table `titreinventaire`
--

CREATE TABLE IF NOT EXISTS `titreinventaire` (
  `id_titre_inventaire` int(11) NOT NULL AUTO_INCREMENT,
  `titre_inventaire` varchar(100) NOT NULL,
  `date` datetime NOT NULL,
  `saisipar` varchar(100) NOT NULL,
  `saisile` datetime NOT NULL,
  PRIMARY KEY (`id_titre_inventaire`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `titreinventaire`
--


-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE IF NOT EXISTS `type` (
  `id_type` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id_type`, `type`) VALUES
(1, 'BON'),
(2, 'DOTATION'),
(3, 'TRANSFERT SORTIE'),
(4, 'DON'),
(5, 'ACHAT'),
(6, 'TRANSFERT ENTREE');

-- --------------------------------------------------------

--
-- Table structure for table `unite`
--

CREATE TABLE IF NOT EXISTS `unite` (
  `id_unite` int(11) NOT NULL AUTO_INCREMENT,
  `unite` varchar(50) NOT NULL,
  PRIMARY KEY (`id_unite`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `unite`
--

INSERT INTO `unite` (`id_unite`, `unite`) VALUES
(1, 'Mètres'),
(2, 'Pièces'),
(3, 'Paires'),
(4, 'Cônnes'),
(5, 'Rouleaux');
