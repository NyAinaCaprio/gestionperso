-- phpMyAdmin SQL Dump
-- version 3.3.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: May 10, 2017 at 04:24 AM
-- Server version: 5.1.66
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gestiondestock`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `reference` varchar(20) NOT NULL,
  `libelleproduit` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `id_categorie` int(11) NOT NULL,
  `id_unite` int(11) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `codebarrefournisseur` varchar(100) NOT NULL,
  `codebarreinterne` varchar(100) NOT NULL,
  `stockalerte` int(11) NOT NULL,
  `saisipar` varchar(100) NOT NULL,
  `saisile` date NOT NULL,
  PRIMARY KEY (`reference`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`reference`, `libelleproduit`, `description`, `id_categorie`, `id_unite`, `photo`, `codebarrefournisseur`, `codebarreinterne`, `stockalerte`, `saisipar`, `saisile`) VALUES
('CAMP0001', 'Gourde', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('CAMP0002', 'Gamelle 03 éléments PH', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('CAMP0003', 'Bêche', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('CAMP0004', 'Bouthéon', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0005', 'Gamelle locale', '3 éléments', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0006', 'Marmite de 100l', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0007', 'Marmite de 60l', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0008', 'Marmite de 50l', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0009', 'Marmite de 45l', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0010', 'Tente de 2 places', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0011', 'Tente de 24 places', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0012', 'Tente de 4 places', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CAMP0013', 'Louche GM', '', 3, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0001', 'Couverture VA PH', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('CCG0002', 'Armature lits picots', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0003', 'Couverture SOMACOU', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0004', 'Matelas de 10 cm', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0005', 'Moustiquaire', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0006', 'Toile lits picots', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0007', 'Traversin', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0008', 'Matelas  8cm', 'MADAFOAM', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0009', 'Lits picots', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0010', 'Matelas 14 EM', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('CCG0011', 'Matelas 14 TM', '', 2, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0001', 'Drapeau N°05', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0002', 'Drapeau N°03', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0003', 'Drapeau 6m', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0004', 'Drapeau 22m', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0005', 'Drapeau N°01', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('DRA0006', 'Pavoisement', '', 6, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0001', 'Toile juté', '', 4, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0002', 'Bouton VA 14', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0003', 'Bouton VA 16', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0004', 'Bouton vert savane 18', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0005', 'Bouton vert lampda', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0006', 'Bouton blanc 18', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0007', 'Bouton blanc 14', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0008', 'Bouton bleu 14', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0009', 'Bouton blanc 8', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0010', 'Bouton noir 12', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0011', 'Bouton noir 14', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0012', 'Bouton pression métalique 12', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0013', 'Bouton bleu 16', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0014', 'Bouton violet', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0015', 'Bouton vert olive 14', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('FOU0016', 'Bouton vert foncé 16', '', 4, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0001', 'Rangers resistance oil', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0002', 'Chaussette verte', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0003', 'Chaussette noire PH', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0004', 'Chaussette de sport blanche PH', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0005', 'Débardeur VA', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0006', 'Sac d''hydratation', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0007', 'Castan camouflée', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0008', 'Survêtement bleu', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0009', 'Ceinturon TAP VA PH', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0010', 'Chaussure basse noire PH', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0011', 'Rangers BGB', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0012', 'Tenue de combat MARCK', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0013', 'Tenue de combat desert', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0014', 'Bérét amarante rouge PR', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-04-29'),
('HAB0015', 'Béret vert PR', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0016', 'Ceinture TAP VA PR', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0017', 'Béret rouge amarante locale', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0018', 'Béret vert locale', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0019', 'Chemise vert olive ', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0020', 'Tenue courte bleu', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0021', 'Epaulette rouge', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0022', 'Ceinture en cuir noir', 'petit', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0023', 'Ceinturon en cuir', 'TAP', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0024', 'Chaussure basse  noir locale', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0025', 'Sandalette', 'J.R', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0026', 'Chandail VA', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0027', 'Ceinture blanche', 'petit', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0028', 'Ceinture de pantalon VA', 'petit', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0029', 'Chaussette noir locale', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0030', 'Chemise blanche', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0031', 'Chemise bleu ciel', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0032', 'Chemise bleu ciel locale', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0033', 'Cravate TM', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0034', 'Espadrille', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0035', 'Imperméable VA', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0036', 'Kiranyl', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0037', 'Lacet blanc', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0038', 'Pantalon viscose', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0039', 'Parka', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0040', 'Poncho camouflée', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0041', 'Mi-bas VA', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0042', 'Casque lourd', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0043', 'Sac au dos camouflée ', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0044', 'Slip pour homme', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0045', 'Gant blanc', '', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0046', 'Slip blanche GM', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0047', 'Tricot rayée', 'BANA', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0048', 'Lacet noir', '60 cm', 1, 3, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0049', 'Ceinture synthétique', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0050', 'Insigne de béret', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('HAB0051', 'Macaron', '', 1, 2, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('TIS0001', 'Tissu vert lampda', 'sous-officier', 5, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('TIS0002', 'Tissu vert savane', '', 5, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('TIS0003', 'Doublure noir', '', 5, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('TIS0004', 'Doublure bleu', '', 5, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03'),
('TIS0005', 'Triplure collante', '', 5, 1, '', '', '', 0, 'RASOARINIRINA Tantely Malala Annick', '2017-05-03');
