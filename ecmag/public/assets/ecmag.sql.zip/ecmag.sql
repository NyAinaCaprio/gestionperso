-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Lun 06 Février 2017 à 22:36
-- Version du serveur: 5.5.8
-- Version de PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `ecmag`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `code_article` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(100) NOT NULL,
  `unite` varchar(20) NOT NULL,
  `quantite_initiale` int(11) NOT NULL,
  `observation` varchar(200) NOT NULL,
  `id_fournisseurs` int(11) NOT NULL,
  `bmouv` int(50) NOT NULL,
  `id_categorie` int(11) NOT NULL,
  PRIMARY KEY (`code_article`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `articles`
--

INSERT INTO `articles` (`code_article`, `designation`, `unite`, `quantite_initiale`, `observation`, `id_fournisseurs`, `bmouv`, `id_categorie`) VALUES
(1, 'TENUE DE COMBAT', 'Nombre', 50, '------', 2, 0, 1),
(2, 'COUVERTURE', 'Nombre', 250, '--', 3, 0, 2),
(3, 'CLA', 'Nombre', 2, '', 4, 0, 7),
(4, 'sdfsdf', 'Nombre', 60, '', 4, 0, 5),
(5, 'XXX', 'Nombre', 60, '', 3, 0, 7),
(6, 'DDDDDD', 'Nombre', 60, '', 3, 0, 2);

-- --------------------------------------------------------

--
-- Structure de la table `articles1`
--

CREATE TABLE IF NOT EXISTS `articles1` (
  `code_article` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `unite` varchar(20) NOT NULL,
  `quantite_initiale` int(11) NOT NULL,
  `observation` varchar(200) NOT NULL,
  `paquetde` int(11) NOT NULL,
  `id_fournisseurs` int(11) NOT NULL,
  PRIMARY KEY (`code_article`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `articles1`
--


-- --------------------------------------------------------

--
-- Structure de la table `articlesenretour`
--

CREATE TABLE IF NOT EXISTS `articlesenretour` (
  `id_sortie` int(11) NOT NULL,
  `code_article` int(11) NOT NULL,
  `date_retour` date NOT NULL,
  `heure_retour` time NOT NULL,
  `quantite_retourner` int(11) NOT NULL,
  `etsouserviceoucorps` varchar(100) NOT NULL,
  `observation` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `articlesenretour`
--

INSERT INTO `articlesenretour` (`id_sortie`, `code_article`, `date_retour`, `heure_retour`, `quantite_retourner`, `etsouserviceoucorps`, `observation`) VALUES
(8, 1, '2016-12-22', '00:00:00', 20, '23', 'obs 1'),
(10, 1, '2016-12-22', '00:00:00', 18, '2', '003');

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `id_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `categorie` varchar(50) NOT NULL,
  PRIMARY KEY (`id_categorie`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `categorie`
--

INSERT INTO `categorie` (`id_categorie`, `categorie`) VALUES
(1, 'HABILLEMENT'),
(2, 'COUCHAGE'),
(3, 'FOURNITURE'),
(4, 'FIL'),
(5, 'TISSUS'),
(6, 'BOUTON'),
(7, 'CAMPEMENT');

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id_clients` int(11) NOT NULL AUTO_INCREMENT,
  `nomprenom` varchar(200) NOT NULL,
  `adresse` varchar(200) NOT NULL,
  `telephone` varchar(200) NOT NULL,
  `observation` varchar(200) NOT NULL,
  PRIMARY KEY (`id_clients`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `clients`
--


-- --------------------------------------------------------

--
-- Structure de la table `detail_entree`
--

CREATE TABLE IF NOT EXISTS `detail_entree` (
  `id_entree` int(11) NOT NULL AUTO_INCREMENT,
  `code_article` int(11) NOT NULL,
  `date_entree` date NOT NULL,
  `quantite_entree` int(11) NOT NULL,
  `id_fournisseur` int(11) NOT NULL,
  `bmouv` varchar(50) NOT NULL,
  `observation` varchar(200) NOT NULL,
  PRIMARY KEY (`id_entree`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `detail_entree`
--

INSERT INTO `detail_entree` (`id_entree`, `code_article`, `date_entree`, `quantite_entree`, `id_fournisseur`, `bmouv`, `observation`) VALUES
(1, 1, '2017-01-06', 60, 0, '', '-'),
(2, 5, '2017-02-06', 50, 0, 'xxxx000', ''),
(3, 5, '2017-02-06', 30, 0, '000500', '----'),
(4, 6, '2016-02-07', 40, 0, '5500666', '');

-- --------------------------------------------------------

--
-- Structure de la table `detail_sortie`
--

CREATE TABLE IF NOT EXISTS `detail_sortie` (
  `id_sortie` int(11) NOT NULL AUTO_INCREMENT,
  `code_article` int(11) NOT NULL,
  `date_sortie` date NOT NULL,
  `quantite_sortie` int(11) NOT NULL,
  `typesortie` varchar(20) NOT NULL,
  `etsouserviceoucorps` varchar(100) NOT NULL,
  `bmouv` varchar(50) NOT NULL,
  `observation` varchar(100) NOT NULL,
  PRIMARY KEY (`id_sortie`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `detail_sortie`
--

INSERT INTO `detail_sortie` (`id_sortie`, `code_article`, `date_sortie`, `quantite_sortie`, `typesortie`, `etsouserviceoucorps`, `bmouv`, `observation`) VALUES
(1, 1, '2017-02-06', 20, 'Dotation', '31', '', '------'),
(2, 1, '2017-02-07', 20, 'Dotation', '3', '', '-----'),
(3, 1, '2017-02-07', 30, 'Dotation', '6', '', '-----'),
(4, 1, '2017-10-10', 20, 'Dotation', '12', 'SS55500', ''),
(5, 5, '2017-02-06', 18, 'Dotation', '17', '00060', 'OBS 005');

-- --------------------------------------------------------

--
-- Structure de la table `detail_sortie_bon`
--

CREATE TABLE IF NOT EXISTS `detail_sortie_bon` (
  `id_sortie` int(11) NOT NULL AUTO_INCREMENT,
  `code_article` int(11) NOT NULL,
  `date_sortie` date NOT NULL,
  `quantite_sortie` int(11) NOT NULL,
  `typesortie` varchar(20) NOT NULL,
  `etsouserviceoucorps` varchar(100) NOT NULL,
  `bmouv` varchar(50) NOT NULL,
  `observation` varchar(100) NOT NULL,
  `etat` varchar(50) NOT NULL,
  PRIMARY KEY (`id_sortie`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `detail_sortie_bon`
--

INSERT INTO `detail_sortie_bon` (`id_sortie`, `code_article`, `date_sortie`, `quantite_sortie`, `typesortie`, `etsouserviceoucorps`, `bmouv`, `observation`, `etat`) VALUES
(1, 1, '2017-02-06', 20, 'Bon', '11', '0DDDD555', '--------', 'En retour'),
(2, 2, '2017-02-06', 50, 'Bon', '17', '0DDDD555', '--------', 'En retour');

-- --------------------------------------------------------

--
-- Structure de la table `etat_de_stock`
--

CREATE TABLE IF NOT EXISTS `etat_de_stock` (
  `code_article` int(11) NOT NULL,
  `quantite_initiale` int(11) NOT NULL,
  `quantite_entree` int(11) NOT NULL,
  `quantite_sortie` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `etat_de_stock`
--

INSERT INTO `etat_de_stock` (`code_article`, `quantite_initiale`, `quantite_entree`, `quantite_sortie`) VALUES
(1, 50, 0, 0),
(2, 250, 0, 0),
(3, 2, 0, 0),
(4, 60, 0, 0),
(5, 60, 0, 0),
(6, 60, 0, 0),
(1, 0, 60, 0),
(5, 0, 50, 0),
(5, 0, 30, 0),
(6, 0, 40, 0),
(1, 0, 0, 20),
(1, 0, 0, 20),
(1, 0, 0, 30),
(1, 0, 0, 20),
(5, 0, 0, 18);

-- --------------------------------------------------------

--
-- Structure de la table `etsouservice`
--

CREATE TABLE IF NOT EXISTS `etsouservice` (
  `id_etsouservice` int(11) NOT NULL AUTO_INCREMENT,
  `etsouservice` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `libelle` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_etsouservice`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=32 ;

--
-- Contenu de la table `etsouservice`
--

INSERT INTO `etsouservice` (`id_etsouservice`, `etsouservice`, `SE`, `libelle`) VALUES
(2, 'CAB', 'SERVICE', 'Cabinet'),
(3, 'SCF', 'SERVICE', 'Service Central et Financier'),
(4, 'SMI', 'SERVICE', 'Service MatÃ©riel de l''Intendence'),
(5, 'JURIDIQUE', 'SERVICE', 'JURIDIQUE'),
(6, 'GAC', 'SERVICE', 'Gestion d''ActivitÃ©s'),
(7, 'SOLDE', 'SERVICE', 'SOLDE'),
(8, 'UGPM', 'SERVICE', 'UnitÃ© de Gestion Passation des MarchÃ©s'),
(9, 'SEOM', 'SERVICE', 'SEOM '),
(10, 'SCMT', 'SERVICE', 'SCMT'),
(11, 'INFO', 'SERVICE', 'Cellule Informatique'),
(12, 'SG', 'SERVICE', 'SG'),
(15, 'ARCHIVES', 'SERVICE', 'ARCHIVES'),
(16, 'COURRIER', 'SERVICE', 'COURRIER'),
(17, 'SPCM', 'SERVICE', 'Service des Personnels Civils et Militaires'),
(18, 'INSPECTION', 'SERVICE', 'INSPECTION'),
(19, 'AUDIT', 'SERVICE', 'AUDIT'),
(20, 'CISL', 'ETABLISSEMENT', 'CISL'),
(21, 'ECMAG', 'ETABLISSEMENT', 'ECMAG'),
(22, 'EIA', 'ETABLISSEMENT', 'EIA'),
(23, 'EMIV', 'ETABLISSEMENT', 'EMIV'),
(24, 'CEMES', 'ETABLISSEMENT', 'Cercle Mess Soanierana'),
(25, 'CISL', 'CENTRE', 'CISL'),
(26, 'SCMT', 'ETABLISSEMENT', 'SCMT'),
(28, 'CORPS CAPSAT', 'CORPS CAPSAT', 'CORPS CAPSAT'),
(29, 'BI SPORT', 'BI SPORT', 'BI SPORT'),
(30, 'MDN', '', ''),
(31, 'EMIC', 'ETABLISSEMENT', 'Etablissement Militaire Industrie de Chaussure');

-- --------------------------------------------------------

--
-- Structure de la table `fiche_de_stock`
--

CREATE TABLE IF NOT EXISTS `fiche_de_stock` (
  `code_article` int(11) NOT NULL,
  `quantite_initiale` int(11) NOT NULL,
  `date` date NOT NULL,
  `quantite_entree` int(11) NOT NULL,
  `quantite_sortie` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `fiche_de_stock`
--

INSERT INTO `fiche_de_stock` (`code_article`, `quantite_initiale`, `date`, `quantite_entree`, `quantite_sortie`) VALUES
(1, 50, '0000-00-00', 0, 0),
(2, 250, '0000-00-00', 0, 0),
(3, 2, '0000-00-00', 0, 0),
(4, 60, '0000-00-00', 0, 0),
(5, 60, '0000-00-00', 0, 0),
(6, 60, '0000-00-00', 0, 0),
(1, 0, '2017-01-06', 60, 0),
(5, 0, '2017-02-06', 50, 0),
(5, 0, '2017-02-06', 30, 0),
(6, 0, '2016-02-07', 40, 0),
(1, 0, '2017-02-06', 0, 20),
(1, 0, '2017-02-07', 0, 20),
(1, 0, '2017-02-07', 0, 30),
(1, 0, '2017-10-10', 0, 20),
(5, 0, '2017-02-06', 0, 18);

-- --------------------------------------------------------

--
-- Structure de la table `fournisseurs`
--

CREATE TABLE IF NOT EXISTS `fournisseurs` (
  `id_fournisseurs` int(11) NOT NULL AUTO_INCREMENT,
  `nomprenom` varchar(200) NOT NULL,
  `adresse` varchar(2000) NOT NULL,
  `telephone` varchar(200) NOT NULL,
  `observation` varchar(500) NOT NULL,
  PRIMARY KEY (`id_fournisseurs`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `fournisseurs`
--

INSERT INTO `fournisseurs` (`id_fournisseurs`, `nomprenom`, `adresse`, `telephone`, `observation`) VALUES
(2, 'RAKOTOMALALA', 'Antananarivo', '0322651215', 'Produits d''entretient'),
(3, 'RABEARIMANANA CLAUDE', 'Antananarivo', '0336251421', 'Consommable Informatique'),
(4, 'RALALA', 'Tulear', '032265251', '----'),
(5, 'RALALA', 'Tulear', '032265251', '----'),
(6, 'RAMAVO', 'MAHAJANGA', '0321552112', '---'),
(7, 'RAKOTONIRINA', 'Antananarivo', '0321526252', '---');

-- --------------------------------------------------------

--
-- Structure de la table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id_login` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(50) NOT NULL,
  `motdepasse` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  PRIMARY KEY (`id_login`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `login`
--

INSERT INTO `login` (`id_login`, `pseudo`, `motdepasse`, `mail`) VALUES
(1, 'ecmag', '12345', 'tina.wdata@gmail.com');
